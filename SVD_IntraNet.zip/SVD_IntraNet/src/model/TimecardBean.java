package model;

import com.github.mygreen.supercsv.annotation.CsvBean;

//タイムカード用のカラムの作成
@CsvBean(header=true)
public class TimecardBean {

	//@CsvColumn(number = 1)
}
