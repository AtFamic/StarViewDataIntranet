function changeUserFor1(){
  obj = document.name1.nameSelect1;

  index = obj.selectedIndex;
    href = obj.options[index].value;
    location.href = href;


}

function changeUserFor2(){
	  obj = document.name2.nameSelect2;

	  index = obj.selectedIndex;
	    href = obj.options[index].value;
	    location.href = href;


	}